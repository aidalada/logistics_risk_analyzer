terraform {
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 4.0"
    }
  }
}

provider "aws" {
  region = "us-east-1"
}

resource "aws_instance" "swarm_manager" {
  ami           = "ami-0c55b159cbfafe1f0" # Ubuntu 20.04 LTS
  instance_type = "t2.micro"
  key_name      = "sre_key"

  tags = {
    Name = "Swarm-Manager-Node"
    Role = "Manager"
  }
}

resource "aws_instance" "swarm_worker" {
  count         = 2
  ami           = "ami-0c55b159cbfafe1f0"
  instance_type = "t2.micro"
  key_name      = "sre_key"

  tags = {
    Name = "Swarm-Worker-Node-${count.index + 1}"
    Role = "Worker"
  }
}
